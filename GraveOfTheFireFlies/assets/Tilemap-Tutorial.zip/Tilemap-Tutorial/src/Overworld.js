class Overworld extends Phaser.Scene{
    constructor(){
        super({key:'overWorldScene'});

        this.VEL = 100;
    }

    preload(){
        this.load.path = "./assets/";
        this.load.spritesheet('slime', 'slime.png',{
            frameWidth: 16,
            frameHeight: 16
        });
        this.load.image('pickable', 'pickable.png');
      
        this.load.image('tilesetImage', 'tileset.png');
        this.load.tilemapTiledJSON('tilemapJSON', 'area01.json');
    }

    create(){
        const map = this.add.tilemap('tilemapJSON');
        const tileset = map.addTilesetImage('tileset', 'tilesetImage');

        // add layer
        const bgLayer = map.createLayer('Background', tileset, 0, 0);
        const terrainLayer = map.createLayer('Terrain', tileset, 0, 0);
        const treeLayer = map.createLayer('Trees', tileset, 0, 0).setDepth(10); // setDepth to hide or kind of overlap the sprite

        // add player
        this.slime = this.physics.add.sprite(32, 32, 'slime', 0);
        this.anims.create({
            key: 'jiggle',
            frameRate: 8,
            repeat: -1,
            frames: this.anims.generateFrameNumbers('slime',{
                start: 0,
                end: 1
            })
        });
        this.slime.play('jiggle');

        this.slime.body.setCollideWorldBounds(true);

        this.pickable = this.physics.add.sprite(64, 64, 'pickable', 0);
        this.pickable1 = this.physics.add.sprite(128, 128, 'pickable', 0);
        this.pickable2 = this.physics.add.sprite(96, 96, 'pickable', 0);


        // enable collision
        terrainLayer.setCollisionByProperty({collides: true});
        treeLayer.setCollisionByProperty({collides: true});
        this.physics.add.collider(this.slime, terrainLayer);
        this.physics.add.collider(this.slime, treeLayer);

        // cameras
        this.cameras.main.setBounds(0, 0, map.widthInPixels, map.heightInPixels);
        this.cameras.main.startFollow(this.slime, true, 0.25, 0.25);
        this.physics.world.bounds.setTo(0, 0, map.widthInPixels, map.heightInPixels);

        //input
        this.cursors = this.input.keyboard.createCursorKeys();

        // initialize score
        this.slimeScore = 0;

        // display score
        let scoreConfig = {
            fontFamily: 'Courier',
            fontSize: '28px',
            backgroundColor: '#6FEDD2',
            color: '#E269FA',
            allign: 'right',
            padding: {
                top: 5,
                bottom: 5,
            },
            fixedWidth: 100
        }
        this.pickableScore = 0;
        this.scoreLeft = this.add.text(200, 200, this.slimeScore, scoreConfig);
          
        // play clock
        scoreConfig.fixedWidth = 0;
        //  this.clock = this.time.delayedCall(game.settings.gameTimer, () => {
        //     this.add.text(game.config.width / 2, game.config.height / 2, 'GAME OVER',
        //         scoreConfig).setOrigin(0.5);
        //     this.add.text(game.config.width / 2, game.config.height / 2 + 64, 'Press (R) to Restart or <- for Menu',
        //         scoreConfig).setOrigin(0.5);
        //     this.gameOver = true;
        //  }, null, this);
 
        // // display time
        // this.showTime = this.add.text(100, 100, this.clock.getElapsedSeconds(), scoreConfig);

    }

         
    
    // check collision
    checkCollision(slime, pickable){
        // simple AABB checking
        if(slime.x < pickable.x + pickable.width &&
            slime.x + slime.width > pickable.x &&
            slime.y < pickable.y + pickable.height &&
            slime.height + slime.y > pickable.y){
            return true;
        } else{
            return false;
        }
    }

    update(){
        if(this.pickableScore == 300){
            this.winner = this.add.text(50, 50, "winner", 0);
        }

        this.direction = new Phaser.Math.Vector2(0);
        if(this.cursors.left.isDown){
            this.direction.x = -1;
        } else if (this.cursors.right.isDown){
            this.direction.x = 1;
        }
       
        if(this.cursors.up.isDown){
            this.direction.y = -1;
        } else if (this.cursors.down.isDown){
            this.direction.y = 1;
        }
        this.direction.normalize();
        this.slime.setVelocity(this.VEL * this.direction.x, this.VEL *
            this.direction.y);

        // check collisions
        if(this.checkCollision(this.slime, this.pickable)){
            this.pickableDestroyed(this.pickable);
            console.log(this.pickableScore);

        }
        if(this.checkCollision(this.slime, this.pickable1)){
            this.pickable1.destroy();  
            this.pickableScore += 1;      
            this.scoreLeft.text =+ this.pickableScore;
        }
        if(this.checkCollision(this.slime, this.pickable2)){
            this.pickable2.destroy(); 
            this.pickableScore += 1;       
            this.scoreLeft.text =+ this.pickableScore;
        }

    
        
        // // updated show the timer
        // this.timeLeft = Math.trunc((game.settings.gameTimer / 1000) - this.clock.getElapsedSeconds());
        // this.showTime.text = this.timeLeft;
    }

    pickableDestroyed(pickable){
        pickable.alpha = 0;
        this.pickable.destroy();
        this.pickableScore += 1;
        this.scoreLeft.text =+ this.pickableScore;

    }

}